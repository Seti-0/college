<div class=footer-top-border></div>
<div class=footer>
    <p>
        Created by <span class=author>Kieran Cosson</span>
    </p>
</div>