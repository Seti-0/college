<head>
    <title>Assignment 3</title>
    <link rel="stylesheet" href="../reset.css">
    <link rel="stylesheet" href="../main.css?v=1">
</head>