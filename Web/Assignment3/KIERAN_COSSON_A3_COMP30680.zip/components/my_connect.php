<?php
/**
 * @var mysqli::__construct $connection
 */

require "config.php";
$connection = new mysqli(servername, username, password);

if ($connection->connect_error) {
    die("Connection Failed: " . $connection->connect_error);
}
