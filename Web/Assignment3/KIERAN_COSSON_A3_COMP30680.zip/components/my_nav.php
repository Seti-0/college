<nav>
    <ul>
        <li class=nav-products>
            <a href="../index.php">
                Products
            </a>
        </li>
        <li class=nav-offices>
            <a href="../offices.php">
                Offices
            </a>
        </li>
        <li class=nav-payments>
            <a href="../payments.php">
                Payments
            </a>
        </li>
    </ul>
    <div class=nav-bottom-border></div>
</nav>