<?php function separator(string $label) { ?>
<div class=separator>
    <div class=inner-separator>
        <?=$label?>
    </div>
</div>
<?php } ?>