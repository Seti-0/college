<?php

const servername = "localhost:3307";
const username = "root";
const password = "";